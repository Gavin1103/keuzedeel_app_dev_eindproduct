demo link
 calculate distance between two points google maps
http://webeasystep.com/demo/codeigniter_demo/global/admin/calculator.html
